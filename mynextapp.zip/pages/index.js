import { Divider } from '@mui/material';
import Head from 'next/head';
import Footerblock from '../components/FooterBlock';
import Populararticles from '../components/PopularArticles';

export default function Home({ results, nonOfResults, copyright }) {

  // console.log("articles===>>", results)
  return (
    <div>
      <Head>
        <title>Webdev</title>
        <meta name='keywords' content="web, development, programming" />
      </Head>
      <Populararticles articles={results} nonOfResults={nonOfResults} />
      <Divider />
      {/* <p>{nonOfResults} Top Stories</p> */}
      <Footerblock />
    </div>

  )
}


export const getStaticProps = async () => {
  const res = await fetch(`https://api.nytimes.com/svc/mostpopular/v2/viewed/1.json?api-key=${process.env.NYT_API_KEY}`)
  const articles = await res.json()

  return {
    props: {
      results: articles.results,
      nonOfResults: articles.num_results,
      copyright: articles.copyright
    }
  }
}