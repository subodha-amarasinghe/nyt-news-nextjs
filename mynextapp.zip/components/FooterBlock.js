import React from 'react';

const Footerblock = () => {
    return (
        <div style={{ textAlign: 'center', padding: '32px' }}>
            Copyright (c) 2022 The New York Times Company. All Rights Reserved.
        </div>
    );
}

export default Footerblock;
