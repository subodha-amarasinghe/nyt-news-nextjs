import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Box, CardActionArea, Divider } from '@mui/material';
import Image from 'next/image';
import articleBlockStyles from '../styles/ArticleBlock.module.css'

const Articleblock = ({ article }) => {
    return (
        <div style={{ marginBottom: '24px' }}>
            {<Card style={{ minHeight: '400px' }}>
                <CardActionArea>
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            {article.title}
                        </Typography>
                        <Typography variant="caption" >
                            {new Date(article.updated).toDateString() + ' (' + new Date(article.updated).toLocaleTimeString() + ')'}
                        </Typography>
                        <Divider />
                        <div style={{ marginTop: '16px' }}>
                            {
                                article.media.length > 0 ?
                                    // <Image
                                    //     src={article.media.find(a => a.type === "image")['media-metadata'][article.media.find(a => a.type === "image")['media-metadata'].length - 1].url}
                                    //     layout="fill"
                                    //     bjectFit="cover"
                                    //     className={articleBlockStyles.imageContainer}
                                    // />
                                    <div className={'imageContainer'}>
                                        <Image src={article.media.find(a => a.type === "image")['media-metadata'][article.media.find(a => a.type === "image")['media-metadata'].length - 1].url} width="440" height='293' layout="responsive" />
                                    </div>
                                    //<img src={article.media[article.media.length - 1].url} alt="Article Image" />
                                    : null
                            }
                            <Typography variant="body2">
                                {article.abstract}
                            </Typography>
                        </div>
                    </CardContent>
                </CardActionArea>
            </Card>}
        </div>
    );
}

export default Articleblock;
