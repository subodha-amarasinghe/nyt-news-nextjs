module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['static01.nyt.com'],
  },
}
